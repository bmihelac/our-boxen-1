# Mercurial Puppet module for Boxen

A module to install the distributed version control system -- [Mercurial](http://mercurial.selenic.com/).

## Usage

```puppet
include mercurial
```

## Required Puppet Modules

* `boxen`
* `homebrew`