# ffmpeg Puppet Module for Boxen

## Usage

```puppet
include ffmpeg
```

## Required Puppet Modules

* boxen
* homebrew
